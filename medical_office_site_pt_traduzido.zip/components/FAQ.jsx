export default function FAQ() {
  return (
    <section>
      <h2>Perguntas Frequentes</h2>
      <p>Encontre respostas para dúvidas comuns sobre nossos serviços.</p>
      <p>Fale Conosco</p>
      <p>Ligar para (555) 123-4567</p>
    </section>
  );
}
