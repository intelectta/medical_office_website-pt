export default function About() {
  return (
    <section>
      <h2>Conheça a Dra. Sarah Johnson</h2>
      <p>Minha Abordagem Terapêutica</p>
      <ul>
        <li>Formação</li>
        <li>Certificações</li>
        <li>Especializações</li>
        <li>Filosofia</li>
      </ul>
      <blockquote>"Toda pessoa tem a capacidade de crescer e se curar em um ambiente acolhedor."</blockquote>
    </section>
  );
}
