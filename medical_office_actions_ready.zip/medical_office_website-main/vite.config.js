import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  base: '/medical_office_website-pt/',
  plugins: [react()],
})
